﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace WriteCodeInTamil
{
    class Program
    {
        static void Main(string[] args)
        {
           
            //  Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.OutputEncoding = Encoding.UTF8;
            System.Windows.Forms.MessageBox.Show("சேமி");

          //  AddProjectReference(@"D:\Anand\Personal\YoutubeVideos\WriteCodeInTamil\WriteCodeInTamil\TestAddReferenceProject\TestAddReferenceProject.csproj");
            //Console.WriteLine(image.ToString());

            Console.ReadLine();
        }
      
    }
}
