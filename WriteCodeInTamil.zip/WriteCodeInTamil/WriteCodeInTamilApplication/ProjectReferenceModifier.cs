﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace WriteCodeInTamilApplication
{
    class ProjectReferenceModifier
    {
        internal static void AddProjectReference(string fileName)
        {
                    


            //create new instance of XmlDocument
            XmlDocument doc = new XmlDocument();

            //load from file
            doc.Load(fileName);
            XmlNodeList elementList = doc.GetElementsByTagName("ItemGroup");
            //create title node
            XmlElement referenceNode = doc.CreateElement("Reference", doc.DocumentElement.NamespaceURI);
          //  if (elementList.Count >0)
            {
                foreach (XmlNode childNode in elementList)
                {
                    
                    if (!childNode.OuterXml.Contains("System.Windows.Forms"))
                        {
                        referenceNode.SetAttribute("Include", "System.Windows.Forms");
                        break;
                    }
                }
           
            }
            elementList[0].AppendChild(referenceNode);

            doc.Save(fileName);

        }
    }
}
