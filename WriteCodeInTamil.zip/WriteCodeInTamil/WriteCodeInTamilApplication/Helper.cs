﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Windows.Forms;

namespace WriteCodeInTamilApplication
{
    public static class Helper
    {
      private  static Dictionary<string, string> tamilToEnglishKeywordDict = new Dictionary<string, string>();
        private static List<string> justReplaceWordDict = new List<string>();
        private static Dictionary<string, string> tamilToEnglishConsoleClassMethodsDict = new Dictionary<string, string>();
        private static Dictionary<string, string> tamilToEnglishConsoleClassMembersDict = new Dictionary<string, string>();
        private static int maxLC = 1; //maxLineCount - should be public
        private const string INSERT_SNIPPET = "#INSERTSNIPPET";
        private static string SUPPORT_FILE_PATH = ConfigurationManager.AppSettings["SUPPORT_FILE_PATH"];
        private const string KEYWORD_DICTIONARY_FILENAME = @"\TamilToEnglishKeywordDictionary.xml";
        private const string CONSOLE_CLASS_METHOD_DICTIONARY_FILENAME = @"\TamilToEnglishConsoleClassMethodsDictionary.xml";
        private const string JUST_TO_USE_AS_IT_IS_FILENAME = @"\JustToUseAsItIs.xml";
        private const string DATA_XML_ELEMENT = @"data/resource";
        internal static void CreateDictionaryObject()
        {

            tamilToEnglishKeywordDict= DictionaryCreator.CreateDictionary(SUPPORT_FILE_PATH + KEYWORD_DICTIONARY_FILENAME, DATA_XML_ELEMENT);

        }
        internal static void CreateJustReplaceDictionary()
        {
           

            justReplaceWordDict = DictionaryCreator.CreateJustToUseList(SUPPORT_FILE_PATH + JUST_TO_USE_AS_IT_IS_FILENAME, DATA_XML_ELEMENT);


        }
        internal static void CreateClassMethodDictionary()
        {

            tamilToEnglishConsoleClassMethodsDict = DictionaryCreator.CreateDictionary(SUPPORT_FILE_PATH + CONSOLE_CLASS_METHOD_DICTIONARY_FILENAME, DATA_XML_ELEMENT);

        }
        internal static void ReplaceTamilToEnglishMethodText(string methodNameInTamil, RichTextBox studioEditorRTB)
        {
            
            bool isAnyJustReplaceCharExists = justReplaceWordDict.Any(methodNameInTamil.Contains);

            if (!isAnyJustReplaceCharExists) return;
            string correctMethodName = string.Empty;
            correctMethodName = methodNameInTamil.Split(new char[] { '.' })[1];
            if (tamilToEnglishConsoleClassMethodsDict.ContainsKey(correctMethodName))
            {
                string methodNameInEnglish=tamilToEnglishConsoleClassMethodsDict[correctMethodName];
                studioEditorRTB.Text= studioEditorRTB.Text.Replace(INSERT_SNIPPET,methodNameInEnglish + INSERT_SNIPPET);
            }
            
           
        }
       



        internal static void PrintLineNos(RichTextBox richTextBox1, TextBox tb_lineNo)
        {
            int linecount = richTextBox1.GetLineFromCharIndex(richTextBox1.TextLength) + 1;
            
            tb_lineNo.Multiline = true;
            if (linecount != maxLC)
            {
                tb_lineNo.Clear();
                for (int i = 1; i < linecount + 1; i++)
                {
                    tb_lineNo.AppendText(Convert.ToString(i) + Environment.NewLine);
                }
                maxLC = linecount;
            }
        }

        
            internal static void ReplaceTamilToEnglishText( string convertedEnglishLanguageProgram,  RichTextBox studioEditorRTB, bool isLoop = false)
        {
         
           
            if (isLoop) //Replace all keywords in a file to English keywords when code snippet is being used from menu
            {
                foreach (string dictionaryTamilKey in tamilToEnglishKeywordDict.Keys)
                {
                    convertedEnglishLanguageProgram = convertedEnglishLanguageProgram.Replace(dictionaryTamilKey, tamilToEnglishKeywordDict[dictionaryTamilKey]);
                }


                foreach (string methodNameInDictionary in tamilToEnglishConsoleClassMethodsDict.Keys)
                {
                    convertedEnglishLanguageProgram = convertedEnglishLanguageProgram.Replace(methodNameInDictionary, tamilToEnglishConsoleClassMethodsDict[methodNameInDictionary]);
                }
            }
          
          studioEditorRTB.Text = convertedEnglishLanguageProgram;
        }
    }
}
