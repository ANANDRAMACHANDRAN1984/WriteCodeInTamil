﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WriteCodeInTamilApplication
{
    class DictionaryCreator
    {
        public static Dictionary<string, string> CreateDictionary(string filePath,string nodesToSelect)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            try
            {
                System.Xml.XmlDocument xml = new System.Xml.XmlDocument();
                xml.Load(filePath);
                System.Xml.XmlNodeList resources = xml.SelectNodes(nodesToSelect);
               
                foreach (System.Xml.XmlNode node in resources)
                {
                    dictionary.Add(node.Attributes["key"].Value, node.InnerText);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);

            }
            return dictionary;
        }

        public static List<string> CreateJustToUseList(string filePath,string nodesToSelect)
        {
            List<string> justToUseList = new List<string>();
            try
            {
                System.Xml.XmlDocument xml = new System.Xml.XmlDocument();
                xml.Load(filePath);
                System.Xml.XmlNodeList resources = xml.SelectNodes(nodesToSelect);

                foreach (System.Xml.XmlNode node in resources)
                {
                    justToUseList.Add(node.InnerText);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);

            }
            return justToUseList;
        }
    }
}
