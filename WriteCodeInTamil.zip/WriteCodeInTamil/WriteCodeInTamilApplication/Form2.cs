﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WriteCodeInTamilApplication
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        //static int currentIndex = 0;
        private void Form2_Load(object sender, EventArgs e)
        {
            //  richTextBox1.Text = "Hello! #PlaceHolder World";
            //currentIndex=   richTextBox1.SelectionStart;
            // Sets the culture to Tamil (India)
            Thread.CurrentThread.CurrentCulture = new CultureInfo("ta-IN");
            // Sets the UI culture to Tamil (India)
            Thread.CurrentThread.CurrentUICulture = new CultureInfo("ta-IN");
           
            foreach (InputLanguage item in InputLanguage.InstalledInputLanguages)
            {
                richTextBox1.AppendText(item.ToString());
                

            }
           
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //string insertText = "$Anand";
            //richTextBox1.Text= richTextBox1.Text.Replace("#PlaceHolder", insertText + "#PlaceHolder");
            //richTextBox1.Paste(); 
            //richTextBox1.Text = richTextBox1.Text.Insert(selectionIndex, insertText);
            //richTextBox1.SelectionStart = selectionIndex; // restore cursor position
            //  ConvertXMLToDictionary();
            //Console.ReadLine();

         
        }

        private static void ConvertXMLToDictionary()
        {
            System.Xml.XmlDocument xml = new System.Xml.XmlDocument();
            xml.Load(@"D:\Anand\Personal\YoutubeVideos\WriteCodeInTamil\WriteCodeInTamil\WriteCodeInTamilApplication\Dictionary.xml");
            System.Xml.XmlNodeList resources = xml.SelectNodes("data/resource");
            SortedDictionary<string, string> dictionary = new SortedDictionary<string, string>();
            foreach (System.Xml.XmlNode node in resources)
            {
                dictionary.Add(node.Attributes["key"].Value, node.InnerText);
            }
            string printString = string.Empty;
            foreach (var item in dictionary.Values)
            {
                printString = printString + item + Environment.NewLine;

            }
            MessageBox.Show(printString);
        }
    }
}
