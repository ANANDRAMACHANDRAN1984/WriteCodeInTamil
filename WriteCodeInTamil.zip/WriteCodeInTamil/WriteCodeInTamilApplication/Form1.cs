﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

using System.Reflection;
using System.Configuration;

namespace WriteCodeInTamilApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }





        private const string INSERT_SNIPPET = "#INSERTSNIPPET";
        private static string codeSnippetInsertedText = string.Empty;
        private static string NAMESPACE_CODE_SNIPPET = ConfigurationManager.AppSettings["NAMESPACE_CODE_SNIPPET"];
        private static string CLASS_CODE_SNIPPET = ConfigurationManager.AppSettings["CLASS_CODE_SNIPPET"];
        private static string FUNCTION_CODE_SNIPPET = ConfigurationManager.AppSettings["FUNCTION_CODE_SNIPPET"];

        internal static string TESTING_OUTPUT_FOLDER_NAME = ConfigurationManager.AppSettings["TESTING_OUTPUT_FOLDER_NAME"];
        private static string TEMPLATE_FILE_PATH = ConfigurationManager.AppSettings["TEMPLATE_FILE_PATH"];
        private const string SOLUTION_FILE_NAME_TO_BUILD = "WriteCodeInTamil.sln";
        internal const string PROJECT_FOLDER_NAME = "WriteCodeInTamil";
        private const string APPLICATION_EXE_NAME = "WriteCodeInTamil.exe";
        private const string PROJECT_FILE_NAME_TO_BUILD = "WriteCodeInTamil.csproj";
        private void NamespaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //   richTextBox1.Text = System.IO.File.ReadAllText(@"D:\Anand\Personal\YoutubeVideos\WriteCodeInTamil\WriteCodeInTamil\WriteCodeInTamilApplication\Snippets\NamespaceSnippet.txt");


        }

       

        private void SaveCodeFile()
        {
            try
            {
                CopyTemplateToOutputDirectory();
                string path = System.IO.Path.Combine(TESTING_OUTPUT_FOLDER_NAME + @"\WriteCodeInTamil", "Program.cs");
                studioEditorRTB.SaveFile(path, RichTextBoxStreamType.PlainText);
                MessageBox.Show("கோப்பு சேமிக்கப்பட்டது");
            }

            catch (Exception ex)
            {
                MessageBox.Show("தவறு நேர்ந்துவிட்டது " + ex.ToString());
            }
        }

        private void வகToolStripMenuItem_Click(object sender, EventArgs e)
        {


            string classSnippet = System.IO.File.ReadAllText(CLASS_CODE_SNIPPET);
            richTextBox1.Text = richTextBox1.Text.Replace(INSERT_SNIPPET, classSnippet);

        }

        private void FunctionToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        
        private void நகழசசToolStripMenuItem_Click(object sender, EventArgs e)
        {

            codeSnippetInsertedText = System.IO.File.ReadAllText(NAMESPACE_CODE_SNIPPET);
            string classSnippet = System.IO.File.ReadAllText(CLASS_CODE_SNIPPET);
            codeSnippetInsertedText = codeSnippetInsertedText.Replace(INSERT_SNIPPET, classSnippet);
            string functionSnippet = System.IO.File.ReadAllText(FUNCTION_CODE_SNIPPET);
            codeSnippetInsertedText = codeSnippetInsertedText.Replace(INSERT_SNIPPET, functionSnippet);

            richTextBox1.Text = codeSnippetInsertedText;
            
            Helper.ReplaceTamilToEnglishText(richTextBox1.Text, studioEditorRTB, true);
            


            Helper.PrintLineNos(richTextBox1, tb_lineNo);
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                buildLogLinkLabel.Visible = false;
                // tamilToEnglishKeywordDict.Add("கன்சோல்", "System.Console, Version = 4.0.0.0, Culture = neutral, PublicKeyToken = b03f5f7f11d50a3a");
                Helper.CreateDictionaryObject();

                Helper.CreateJustReplaceDictionary();

                Helper.CreateClassMethodDictionary();


                comboBox1.Items.Clear();
                comboBox1.Items.Add("கன்சோல் விண்ணப்பம்");
                comboBox1.Items.Add("ஜன்னல் உருவாக்கும் விண்ணப்பம்");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"தவறு நேர்ந்துவிட்டது  {ex.Message}");
            }
        }

        private void தகததலToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Helper.ReplaceTamilToEnglishText(richTextBox1.Text, studioEditorRTB, true);
            SaveCodeFile();//
            bool buildStatus = BuildManager.BuildProject(TESTING_OUTPUT_FOLDER_NAME, PROJECT_FOLDER_NAME);
            if (buildStatus) MessageBox.Show("தொகுப்பு வெற்றி பெற்றது"); else MessageBox.Show("தொகுப்பு தோல்வி அடைந்தது ");
            //Show build log in text area beneath 
            buildLogLinkLabel.Visible = true;
        }

       






        private void ஓடToolStripMenuItem_Click(object sender, EventArgs e)
        {


            try
            {
                SaveCodeFile();
                string path = System.IO.Path.Combine(TESTING_OUTPUT_FOLDER_NAME + @"\WriteCodeInTamil\bin\Debug", APPLICATION_EXE_NAME);
                if (!File.Exists(path))
                {
                    Helper.ReplaceTamilToEnglishText(richTextBox1.Text, studioEditorRTB, true);
                    bool buildStatus = BuildManager.BuildProject(TESTING_OUTPUT_FOLDER_NAME, PROJECT_FOLDER_NAME);
                    if (buildStatus) MessageBox.Show("தொகுப்பு வெற்றி பெற்றது"); else { MessageBox.Show("தொகுப்பு தோல்வி அடைந்தது "); return; }

                    buildLogLinkLabel.Visible = true;
                }
                Process.Start(path);
            }

            catch (Exception ex)
            {
                MessageBox.Show("தவறு நேர்ந்துவிட்டது " + ex.Message);
            }

        }

        

        private void CopyTemplateToOutputDirectory()
        {
            try
            {
               string solutionFilepath = System.IO.Path.Combine(TEMPLATE_FILE_PATH, SOLUTION_FILE_NAME_TO_BUILD);
                string projectFilepath = System.IO.Path.Combine(TEMPLATE_FILE_PATH, PROJECT_FOLDER_NAME, PROJECT_FILE_NAME_TO_BUILD);
                string solutionFileInDestinationpath = System.IO.Path.Combine(TESTING_OUTPUT_FOLDER_NAME, SOLUTION_FILE_NAME_TO_BUILD);

                if (File.Exists(solutionFileInDestinationpath))
                {
                    return;

                }
                if ((!File.Exists(solutionFilepath)) || (!File.Exists(projectFilepath)))
                {
                    MessageBox.Show("டெம்ப்ளட் இல்லை/Template Not available.Please contact administrator");

                }
                else
                {
                    try
                    {

                        if (Directory.Exists(TESTING_OUTPUT_FOLDER_NAME))
                            System.IO.Directory.Delete(TESTING_OUTPUT_FOLDER_NAME, true);
                    }

                    catch (System.IO.IOException ioException)
                    {
                        MessageBox.Show("தவறு நேர்ந்துவிட்டது " +ioException.Message);
                    }
                    string[] directories = System.IO.Directory.GetDirectories(TEMPLATE_FILE_PATH);
                    // Copy the files and overwrite destination files if they already exist.
                    foreach (string d in directories)
                    {
                        // Use static Path methods to extract only the file name from the path.
                        string directoryName = System.IO.Path.GetDirectoryName(d);

                        DirectoryCopy(directoryName, TESTING_OUTPUT_FOLDER_NAME, true);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("தவறு நேர்ந்துவிட்டது " + ex.Message );
                //throw;
            }
        }

        private static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            // Get the subdirectories for the specified directory.
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);

            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException(
                    "தவறு நேர்ந்துவிட்டது /Source directory does not exist or could not be found: "
                    + sourceDirName);
            }

            DirectoryInfo[] dirs = dir.GetDirectories();

            // If the destination directory doesn't exist, create it.       
            Directory.CreateDirectory(destDirName);

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string tempPath = Path.Combine(destDirName, file.Name);
                file.CopyTo(tempPath, false);
            }

            // If copying subdirectories, copy them and their contents to new location.
            if (copySubDirs)
            {
                foreach (DirectoryInfo subdir in dirs)
                {
                    string tempPath = Path.Combine(destDirName, subdir.Name);
                    DirectoryCopy(subdir.FullName, tempPath, copySubDirs);
                }
            }
        }

        public Dictionary<string, string> GetAllClassesAndMethodsOfAssembly(string assemblyName)

        {

            System.Type type = assemblyName.GetType();
            var assem1 = Assembly.Load(assemblyName);



            //Another Way

            Assembly assem2 = Assembly.Load(assemblyName);
            Dictionary<string, string> classMethodCollection = new Dictionary<string, string>();

            //Get List of Class Name

            Type[] types = assem2.GetTypes();

            foreach (Type tc in types)
            {

                MemberInfo[] methodName = tc.GetMethods();

                classMethodCollection.Add(tc.Name, string.Empty);

                foreach (MemberInfo method in methodName)

                {

                    if (method.ReflectedType.IsPublic)

                    {

                        classMethodCollection[tc.Name] = method.Name.ToString();

                    }



                }

            }
            return classMethodCollection;

        }

        private void RichTextBox1_KeyUp(object sender, KeyEventArgs e)
        {
            Helper.PrintLineNos(richTextBox1, tb_lineNo);
        }



     

        private void RichTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
           

                //if a (.) dot, ; semicolon or enter is entered call this method. - New logic
                if ((e.KeyChar == 46) || (e.KeyChar == (char)13) || (e.KeyChar == (char)59))
                    Helper.ReplaceTamilToEnglishText(richTextBox1.Text, studioEditorRTB, true);          


        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //D:\Anand\Testing\ConsoleTemplate
            CopyTemplateToOutputDirectory();
        }

        private void SeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveCodeFile();
        }

        

        private void AddReferenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string projectFilepath = System.IO.Path.Combine(TESTING_OUTPUT_FOLDER_NAME, PROJECT_FOLDER_NAME, PROJECT_FILE_NAME_TO_BUILD);
            ProjectReferenceModifier.AddProjectReference(projectFilepath);

        }
        private static string tamilTextinTextBox = string.Empty;
        private void BuildLogLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //Open a text file
          
            string fileName = $"{ BuildManager.SUPPORT_FILE_PATH}\\build.log";
            if (System.IO.File.Exists(fileName))
            {
                System.IO.StreamReader objReader;
                objReader = new StreamReader(fileName);
                tamilTextinTextBox = richTextBox1.Text;
                returnToMyCodeLinkLabel.Visible = true;
                richTextBox1.Text = objReader.ReadToEnd();
                objReader.Close();
            }
            else {
                MessageBox.Show("File not exists" + fileName);
            }
            
        }

        private void ReturnToMyCodeLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            richTextBox1.Text = tamilTextinTextBox;
            returnToMyCodeLinkLabel.Visible = false;
        }
    }
}
