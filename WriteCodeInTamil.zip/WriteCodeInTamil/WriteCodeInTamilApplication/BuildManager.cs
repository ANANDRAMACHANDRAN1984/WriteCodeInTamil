﻿using Microsoft.Build.BuildEngine;
using Microsoft.Build.Evaluation;
using Microsoft.Build.Execution;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WriteCodeInTamilApplication
{
    class BuildManager
    {
        internal static string SUPPORT_FILE_PATH = ConfigurationManager.AppSettings["SUPPORT_FILE_PATH"];
        internal static bool BuildProjectOld(string projectfilePath, string solutionFileName)
        {
            try
            {


                string projectFileName = string.Format(@"{0}\{1}.sln", projectfilePath, solutionFileName);
                Microsoft.Build.Logging.ConsoleLogger logger = new Microsoft.Build.Logging.ConsoleLogger();

                ProjectCollection pc = new ProjectCollection();
                pc.Loggers.Add(logger);
                Dictionary<string, string> GlobalProperty = new Dictionary<string, string>();

                GlobalProperty.Add("Configuration", "Debug");

                GlobalProperty.Add("Platform", "Any CPU");
                GlobalProperty.Add("CodeContractsRunInBackground", "false");//get ouptut

                BuildRequestData BuidlRequest = new BuildRequestData(projectFileName, GlobalProperty, null, new string[] { "Build" }, null);

                BuildResult buildResult = Microsoft.Build.Execution.BuildManager.DefaultBuildManager.Build(new BuildParameters(pc), BuidlRequest);
                Microsoft.Build.Logging.FileLogger fileLogger = new Microsoft.Build.Logging.FileLogger();
                
            fileLogger.Parameters = $"logfile={SUPPORT_FILE_PATH}\build.log";
               // BuidlRequest.
                if (buildResult.OverallResult == BuildResultCode.Failure)
                    return false;
                else
                    return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("தவறு நேர்ந்துவிட்டது " + ex.Message);
                return false;
            }
        }

   
        internal static bool BuildProject(string projectfilePath, string solutionFileName)
        {
            // Instantiate a new Engine object
            Engine engine = new Engine();

            // Point to the path that contains the .NET Framework 2.0 CLR and tools
            //engine.BinPath = @"c:\windows\microsoft.net\framework\v2.0.xxxxx";
            
            // Instantiate a new FileLogger to generate build log
            FileLogger logger = new FileLogger();

            // Set the logfile parameter to indicate the log destination
            logger.Parameters = $"logfile={SUPPORT_FILE_PATH}\\build.log";

            // Register the logger with the engine
            engine.RegisterLogger(logger);
            string projectFileName = string.Format(@"{0}\{1}.sln", projectfilePath, solutionFileName);
            // Build a project file
            bool success = engine.BuildProjectFile(projectFileName);

            //Unregister all loggers to close the log file
            engine.UnregisterAllLoggers();

       
            return success;
        }
    }
}
