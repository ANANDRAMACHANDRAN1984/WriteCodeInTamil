﻿namespace WriteCodeInTamilApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddReferenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.namespaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.வகToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.நகழசசToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.தகததலToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ஓடToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.studioEditorRTB = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_lineNo = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.buildLogLinkLabel = new System.Windows.Forms.LinkLabel();
            this.returnToMyCodeLinkLabel = new System.Windows.Forms.LinkLabel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenuToolStripMenuItem,
            this.namespaceToolStripMenuItem,
            this.தகததலToolStripMenuItem,
            this.ஓடToolStripMenuItem,
            this.seToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1276, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileMenuToolStripMenuItem
            // 
            this.fileMenuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddReferenceToolStripMenuItem});
            this.fileMenuToolStripMenuItem.Name = "fileMenuToolStripMenuItem";
            this.fileMenuToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.fileMenuToolStripMenuItem.Text = "பட்டியல்";
            // 
            // AddReferenceToolStripMenuItem
            // 
            this.AddReferenceToolStripMenuItem.Name = "AddReferenceToolStripMenuItem";
            this.AddReferenceToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.AddReferenceToolStripMenuItem.Text = "குறிப்புசேர்";
            this.AddReferenceToolStripMenuItem.Click += new System.EventHandler(this.AddReferenceToolStripMenuItem_Click);
            // 
            // namespaceToolStripMenuItem
            // 
            this.namespaceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.வகToolStripMenuItem,
            this.நகழசசToolStripMenuItem});
            this.namespaceToolStripMenuItem.Name = "namespaceToolStripMenuItem";
            this.namespaceToolStripMenuItem.Size = new System.Drawing.Size(100, 20);
            this.namespaceToolStripMenuItem.Text = "பெயர்வெளி";
            this.namespaceToolStripMenuItem.Click += new System.EventHandler(this.NamespaceToolStripMenuItem_Click);
            // 
            // வகToolStripMenuItem
            // 
            this.வகToolStripMenuItem.Name = "வகToolStripMenuItem";
            this.வகToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.வகToolStripMenuItem.Text = "வகை ";
            this.வகToolStripMenuItem.Click += new System.EventHandler(this.வகToolStripMenuItem_Click);
            // 
            // நகழசசToolStripMenuItem
            // 
            this.நகழசசToolStripMenuItem.Name = "நகழசசToolStripMenuItem";
            this.நகழசசToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.நகழசசToolStripMenuItem.Text = "நிகழ்ச்சி";
            this.நகழசசToolStripMenuItem.Click += new System.EventHandler(this.நகழசசToolStripMenuItem_Click);
            // 
            // தகததலToolStripMenuItem
            // 
            this.தகததலToolStripMenuItem.Name = "தகததலToolStripMenuItem";
            this.தகததலToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.தகததலToolStripMenuItem.Text = "தொகு";
            this.தகததலToolStripMenuItem.Click += new System.EventHandler(this.தகததலToolStripMenuItem_Click);
            // 
            // ஓடToolStripMenuItem
            // 
            this.ஓடToolStripMenuItem.Name = "ஓடToolStripMenuItem";
            this.ஓடToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.ஓடToolStripMenuItem.Text = "ஓடு ";
            this.ஓடToolStripMenuItem.Click += new System.EventHandler(this.ஓடToolStripMenuItem_Click);
            // 
            // seToolStripMenuItem
            // 
            this.seToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("seToolStripMenuItem.BackgroundImage")));
            this.seToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("seToolStripMenuItem.Image")));
            this.seToolStripMenuItem.Name = "seToolStripMenuItem";
            this.seToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.seToolStripMenuItem.Text = "சேமி ";
            this.seToolStripMenuItem.Click += new System.EventHandler(this.SeToolStripMenuItem_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(231, 27);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(449, 521);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            this.richTextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.RichTextBox1_KeyPress);
            this.richTextBox1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.RichTextBox1_KeyUp);
            // 
            // studioEditorRTB
            // 
            this.studioEditorRTB.Location = new System.Drawing.Point(686, 27);
            this.studioEditorRTB.Name = "studioEditorRTB";
            this.studioEditorRTB.ReadOnly = true;
            this.studioEditorRTB.Size = new System.Drawing.Size(449, 521);
            this.studioEditorRTB.TabIndex = 4;
            this.studioEditorRTB.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label1.Location = new System.Drawing.Point(-3, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Choose Project Type";
            // 
            // tb_lineNo
            // 
            this.tb_lineNo.Location = new System.Drawing.Point(195, 27);
            this.tb_lineNo.Multiline = true;
            this.tb_lineNo.Name = "tb_lineNo";
            this.tb_lineNo.Size = new System.Drawing.Size(30, 521);
            this.tb_lineNo.TabIndex = 6;
            this.tb_lineNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(1, 53);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // buildLogLinkLabel
            // 
            this.buildLogLinkLabel.AutoSize = true;
            this.buildLogLinkLabel.Location = new System.Drawing.Point(387, 9);
            this.buildLogLinkLabel.Name = "buildLogLinkLabel";
            this.buildLogLinkLabel.Size = new System.Drawing.Size(51, 13);
            this.buildLogLinkLabel.TabIndex = 9;
            this.buildLogLinkLabel.TabStop = true;
            this.buildLogLinkLabel.Text = "Build Log";
            this.buildLogLinkLabel.Visible = false;
            this.buildLogLinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.BuildLogLinkLabel_LinkClicked);
            // 
            // returnToMyCodeLinkLabel
            // 
            this.returnToMyCodeLinkLabel.AutoSize = true;
            this.returnToMyCodeLinkLabel.Location = new System.Drawing.Point(455, 11);
            this.returnToMyCodeLinkLabel.Name = "returnToMyCodeLinkLabel";
            this.returnToMyCodeLinkLabel.Size = new System.Drawing.Size(189, 13);
            this.returnToMyCodeLinkLabel.TabIndex = 10;
            this.returnToMyCodeLinkLabel.TabStop = true;
            this.returnToMyCodeLinkLabel.Text = "கோடுக்கு திரும்பு/Return to Code";
            this.returnToMyCodeLinkLabel.Visible = false;
            this.returnToMyCodeLinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ReturnToMyCodeLinkLabel_LinkClicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1276, 635);
            this.Controls.Add(this.returnToMyCodeLinkLabel);
            this.Controls.Add(this.buildLogLinkLabel);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.tb_lineNo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.studioEditorRTB);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem namespaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem வகToolStripMenuItem;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.ToolStripMenuItem நகழசசToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem தகததலToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ஓடToolStripMenuItem;
        private System.Windows.Forms.RichTextBox studioEditorRTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_lineNo;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ToolStripMenuItem seToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileMenuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddReferenceToolStripMenuItem;
        private System.Windows.Forms.LinkLabel buildLogLinkLabel;
        private System.Windows.Forms.LinkLabel returnToMyCodeLinkLabel;
    }
}

